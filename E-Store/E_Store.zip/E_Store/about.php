<?php include 'includes/conn.php' ?>
<html>
    <head>
        <title>About Us</title>
        <?php include 'includes/links.php'; ?>
    </head>
    <body>
        <?php include 'includes/header.php'; ?>
        <div class="container tpmrgnd">
            <div class="row info">
                <div class="infodiv">
                    <h3>WHO WE ARE..?</h3><br/>
                    <img src="img/abtus.png" alt="About Us"/>
                    <p>E-Store is an American electronic e-commerce company with the headquarters in Washington. It is one of the largest internet based retailer
                        in the United states. E-Store started as an online blog, but soon diversified selling gadges and earphones. E-Store also sets certain low end 
                    products like USB cables and other accessories. E-Store has seperate retail websites for US, UK, Ireland, France, Canada, Germany, Italy, 
                    Spain, Netherlands, Australia, Brazil, Japan, China, India and Mexico. E-Store also offers international shipping.</p>
                </div>
                
                <div class="infodiv">
                    <h3>OUR HISTORY</h3><br/>
                    <h5 class="focust">1998</h5>
                    <p>The company was founded in 1998, spurred by what Velos called his "Initiating framework" 
                        which described his efforts as an initiate to participate in the Internet business boom during that time. 
                        In 1998, Velos left his employment as president of Ofcol & Co. and moved to Seattle. He began to work on 
                        a business plan for what would eventually become E-Store.</p>
                    
                    <h5 class="focust">2002</h5>
                    <p>In January 2002 E-store has received a funding of $12 million from Venture Partners and Indo-US Venture Partners.</p>
                    
                    <h5 class="focust">2008</h5>
                    <p>In July 2008, the company raised a further $45 million from Bessemer Venture Partners, along with existing 
                        investors Venture Partners and indo US Venture Partners.</p>
                    
                    <h5 class="focust">2015</h5>
                    <p>E-Store received its 3rd round of funding of $133 million on Feb-2015. The 3rd round of funding
                        was led by Fcom with all the current institutional Investors.</p>                    
                </div>
                <div class="infodiv">
                    <h3>OPPORTUNITIES</h3><br/>
                    <h4 class="focust">Available Roles.</h4>
                    <ol type="1">
                        <li>Jr/Sr. Web Developer [Full Time Role + also available as a 6 Months Internship)</li>
                        <li>Business Apprentice [6 Months Internship)</li>
                        <li>Manager at backend operations (Full Time Role + also available as a 6 Months Internship]</li>
                    </ol>
                </div>
            </div>
        </div>
        
        <?php include 'includes/footer.php'; ?>
    </body>
</html>

