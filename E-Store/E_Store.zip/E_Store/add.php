<?php include 'includes/conn.php';
$return = $_GET['ret'];
$meth = $_GET['met'];
$uid = $_SESSION['id'];
$pid = $_GET['pid'];
if($meth=='cart2'){
    $status='Added to cart';
    $cqry = "update user_prod set status ='$status' where uid='$uid' and pid='$pid' and status='wishlist';";
    mysqli_query($con, $cqry) or die(mysqli_error($con));
}else{
if($meth=='cart'){
    $status='Added to cart';
    $cqry = "delete from user_prod where uid='$uid' and pid='$pid' and status='wishlist'; ";
    mysqli_query($con, $cqry) or die(mysqli_error($con));
}
elseif ($meth=='wish') {$status='wishlist';}
$cqry = "insert into user_prod (uid,pid,status) values ('$uid','$pid','$status');";
mysqli_query($con, $cqry) or die(mysqli_error($con));
}
header("location: $return");
?>
