<?php include'includes/conn.php' ?>
<html>
    <head>
        <title>cart</title>
        <?php include 'includes/links.php' ?>
    </head>
    <body>
        <?php  include 'includes/validation.php';  include 'includes/header.php' ?>
        
        <div class="container tpmrgnm">
            <div class="row">
                <table class="table rec">
                    <tr><th>NAME</th><th>DESCRIPTION</th><th>PRICE</th><th></th></tr>
                    <?php 
                    $uid = $_SESSION['id'];
                    $status = 'Added to cart';
                    $carqry = "select pid,prod_name,description,price from user_prod inner join products on pid=products.id and uid=2 and status='$status' ";
                    $carqry_res = mysqli_query($con, $carqry) or die(mysqli_error($con));
                    $total = 0;
                    while ($row = mysqli_fetch_array($carqry_res)) { $id = $row['pid'] ?>
                    <tr>
                        <td><?=$row['prod_name']?></td>
                        <td><?=$row['description']?></td>
                        <td><?="Rs. ".$row['price']?></td>
                        <td><a href="rem.php?met=cart&pid=<?=$id?>&ret=cart.php" class="btn btn-info btn-block">Remove</a></td>
                    </tr>
                    <?php $total+=$row['price'];  } ?>
                    <tr>
                        <td></td>
                        <td></td>
                        <td><?="Rs. ".$total?></td>
                        <td>
                            <?php if($total != 0){ ?>
                            <a href="msg.php?msg=success" class="btn btn-success btn-block" >Confirm Order</a>
                            <?php }else{ ?>
                            <a href="home.php" class="btn btn-link btn-block" >Shop here</a>
                            <?php } ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <?php include 'includes/footer.php' ?>
    </body>
</html>
