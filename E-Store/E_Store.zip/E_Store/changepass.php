<?php include 'includes/conn.php'; 
    if(isset($_POST['opass']) && isset($_POST['npass']) && isset($_POST['rnpass'])){
        $uid = $_SESSION['id'];
        $pwdq = "select id,email,pass from users where id = '$uid';";
        $pres = mysqli_query($con, $pwdq) or die(mysqli_error($con));
        $res = mysqli_fetch_array($pres);
        
        $owd = $res['pass'];
        $o = mysqli_real_escape_string($con, $_POST['opass']);       
        if($owd != $o){  header('location: changepass.php?error=incorret old password');  exit(); }
        
        $n = mysqli_real_escape_string($con, $_POST['npass']);
        $r = mysqli_real_escape_string($con, $_POST['rnpass']);
        if(strlen($n)<6 or strlen($r)<6){  header('location: changepass.php?error=password should be atleast 6 character long');  exit(); }
        if($n != $r){  header('location: changepass.php?error=passwords do no match');  exit(); }
        
        $uqry = "update users set pass='$n' where id = '$uid';";
        mysqli_query($con, $uqry) or die(mysqli_error($con));
        header('location: settings.php');
                
    }
?>
<html>
    <head>
        <title>Change Password</title>
        <?php include 'includes/links.php'; ?>
        <style>
            
        </style>
    </head>
    <body>
        <?php include 'includes/validation.php' ?>
        <div class="container tpmrgnl">
            <div class="row">
                <div class="col-xs-8 col-xs-offset-2 col-md-6 col-md-offset-3">
                    <div class="panel-primary">
                        <div class="panel-title cptitle"><h3>CHANGE PASSWORD</h3></div>
                        <div class="panel-body">
                            <form method="post">
                                <div class="form-group">
                                    <input type="password" class="form-control" name="opass" placeholder="old password" required />
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="npass" placeholder="new password" required />
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="rnpass" placeholder="re-enter new password" required />
                                </div>
                                <div class='form-group'>
                                    <span class="error"><?php if(isset($_GET['error'])){    echo '*'.$_GET['error'];} ?></span>
                                </div>
                                <input type="submit" class="btn btn-block btn-primary" value="submit" />
                            </form>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
    </body>
</html>
