<?php include 'includes/conn.php'; ?>
<html>
    <head>
        <title>Contact Us</title>
        <?php include 'includes/links.php'; ?>
        <style>
            
        </style>
    </head>
    <body>
        <?php include 'includes/header.php'; ?>
        <div class="container tpmrgnd">
            <div class="row">
                <div class="contop">
                    <div>
                        <h3>LIVE SUPPORT</h3>
                        <h5 class="focust">24 hours | 7 days a week | 365 days a year Live Technical Support</h5>
                        <p>It is a long established fact Ipsum is that it has have that a reader will be distracted by 
                            the readable content of a page when looking at its layout. The point of using Lorem a 
                            more-or-less normal distribution of letters. There are many variations of passages of Lorem Ipsum available, 
                            but the majority suffered alteration in some form, by inject humour, or randomised words 
                            which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, 
                            you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>
                    </div>                    
                    <img src="img/cus.PNG" alt="contact us" />                   
                </div>
                <div class="contop">
                    <div class="contform">
                        <div class="form-group">
                            <label for="name"> Name:</label>        
                            <input type="text" class="form-control" name="name" />
                        </div>
                        <div class="form-group">
                            <label for="email"> Email:</label>      
                            <input type="email" class="form-control" name="email" />
                        </div>
                        <div class="form-group">
                            <label for="msg"> Message:</label>
                            <textarea class="form-control"></textarea>                            
                        </div>   
                        <input class="form-control btn-info" type="submit" value="submit" />
                    </div>
                    <div class="contadr">                        
                        <h3>Company Information</h3>
                        <p>500 E-store pvt.ltd</p>
                        <p>22-56-2-9 Sit Amet, Lorem,</p>
                        <p>USA</p>
                        <p>Phone:(00) 222 666 444</p>
                        <p>Fax: (000) 000 00 00 0</p>
                        <p>Email: e-store@gmail.com</p>
                        <p>Follow on: Facebook, Twitter @e-store</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="navbar-fixed-bottom"><?php include 'includes/footer.php'; ?></div>

    </body>
</html>

