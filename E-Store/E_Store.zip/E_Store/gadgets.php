<?php require 'includes/conn.php';
$pqry = "select * from products where id>=17 and id<=40;";
$pqry_res = mysqli_query($con, $pqry) or die(mysqli_error($con));
include 'includes/addedtocart.php';
?>

<html>
    <head>
        <title>gadgets</title>
        <?php include 'includes/links.php'; ?>
    </head>
    <body>
        <?php include 'includes/validation.php'; include 'includes/header.php'; ?>
        
        <div class="container tpmrgnd">
            <div class="rowflex">
                <?php    while($res=mysqli_fetch_array($pqry_res)){
                 $id = $res['id'];  $n = $res['prod_name'];    $p = $res['price'];   $d = $res['description']; 
                 $ret = "gadgets.php#$id";
                 ?>                    
                <div class="col30">
                        <?= "<div class='thumbnail' id='$id' >" ?>
                            <img class="img-rounded img-responsive" src="img/<?=$id?>.jpg" alt="<?=$n?>"/>
                            <div class="dropdown img_deta">
                                    <a href='' class="dropdown-toggle" data-toggle='dropdown'>
                                        <h2 class="focust"><?= $n?></h2>            
                                        <h4><?= "Rs. " . $p?></h4>
                                    </a>
                                    <div class="dropdown-menu"><?= $d?></div>
                            </div>
                            <form class="form-inline butts">
                                <?php if(addedtocart($con, $id)){ ?>
                                <div class="form-group butt7">
                                    <a href="rem.php?met=cart&pid=<?=$id?>&ret=<?=$ret?>"  class="btn btn-success btn-block">Added to <span class="glyphicon glyphicon-shopping-cart"></span></a>
                                </div>
                                <?php }else{ ?>
                                <div class="form-group butt7">
                                    <a href="add.php?met=cart&pid=<?=$id?>&ret=<?=$ret?>" class="btn btn-primary btn-block"><span class="glyphicon glyphicon-shopping-cart"></span></a>
                                </div>
                                <?php if(inwishlist($con, $id)){ ?>
                                 <div class="form-group butt3">
                                    <a href="rem.php?met=wish&pid=<?=$id?>&ret=<?=$ret?>" class="btn btn-success btn-block"><span class="glyphicon glyphicon-star"></span></a>
                                </div>
                                <?php }else{ ?>
                                <div class="form-group butt3">
                                    <a href="add.php?met=wish&pid=<?=$id?>&ret=<?=$ret?>" class="btn btn-link btn-block"><span class="glyphicon glyphicon-star-empty"></span></a>
                                </div>
                                
                                <?php }} ?>
                            </form>
                        </div>
                <?= "</div>" ?>                    
                <?php }?>
            </div>
        </div>
        <?php include 'includes/footer.php'; ?> 
    </body>
</html>
