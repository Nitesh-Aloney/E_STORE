<?php include 'includes/conn.php'; ?>
<html>
    <head>
        <meta name="title" content="Shop Earphones and Gadets | E-Store" />
        <meta name="view-port" content="width=device-width, initial-scale=1.0" />
        <meta name="description" content="Find the best Earphones and Gadgets here at E-Store at best prices from premium brands."  />
        <meta name="keywords" content="phones, Tablets, earphones, latest electronics, electronics, latest mobile phones, latest electronics at best prices, 
              latest earphones at best prices, lea, reed, one pro, samsin, micromin, jbl, boss, skullx. " />
        <title>E-STORE</title>
        <?php include 'includes/links.php'; ?>            
        <style>
            
        </style>
    </head>
    <body>
        <?php include 'includes/header.php'; ?>
        <?php if(isset($_SESSION['email'])){ ?>
        <div class="container-fluid">
            <div class="row">
                <div class="bcg">
                    <div class="in-bcg">
                        <div class="logo">
                            <h1 class="focust">E-STORE</h1>
                            <h4>Earphones, Mobiles and Tablets.</h4>
                        </div>                    
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xs-6">
                    <div class="thumbnail hometh">
                        <img src="img/ep.jpg" alt="earphones" class="img-rounded img-responsive">
                        <a href="earphones.php">
                            <h2 class="focust">EARPHONES</h2>
                            <h4>Groove like never before.</h4>
                        </a>
                    </div>
                </div>
                <div class="col-xs-6">
                    <div class="thumbnail hometh">
                        <img src="img/pt.jpg" alt="phones and tablets" class="img-rounded img-responsive">
                        <a href="gadgets.php">
                            <h2 class="focust">GADGETS</h2>
                            <h4>world at your finger tips.</h4>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php }else{ ?>
        <div class="container tpmrgnd">
            <div class="row">
                <div class="homebcg">
                    <div class="title">
                        <h2>E-STORE</h2>
                        <h4>we bring you the latest collection of earphones and gadgets from premium brands.</h4>
                    </div>
                    <button data-toggle="modal" data-target="#loginmodal" class="btn btn-default btn-lg snbut">Shop Now</button>
                </div>
                <div class="col-xs-4">
                    <div class="thumbnail noborder">
                        <img src="img/i1.jpeg" alt="earphones" class="bshadow"/>
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="thumbnail noborder">
                        <img src="img/i2.jpeg" alt="Phones" class="bshadow"/>
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="thumbnail noborder">
                        <img src="img/i3.jpg" alt="Tablets" class="bshadow"/>
                    </div>
                </div>
            </div>
        </div>
            
        <?php } ?>
        
         <?php include 'includes/footer.php'; ?>
    </body>
</html>
