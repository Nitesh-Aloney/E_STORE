<?php
function addedtocart($con,$id){    
    $uid = $_SESSION['id'];
    $cqry = "select user_prod.status from user_prod where uid='$uid' and pid='$id';";
    $cqry_res = mysqli_query($con, $cqry) or die(mysqli_error($con));
    $res = mysqli_fetch_array($cqry_res);
    $o = $res['status'];
    return (strcasecmp($o, 'Added to cart')==0)?true:false ;
}
function inwishlist($con,$id){
    $uid = $_SESSION['id'];
    $cqry = "select status from user_prod where uid='$uid' and pid='$id';";
    $cqry_res = mysqli_query($con, $cqry) or die(mysqli_error($con));
    $res = mysqli_fetch_array($cqry_res);
    $o = $res['status'];
    return (strcasecmp($o, 'wishlist')==0)?true:false ;
}
?>