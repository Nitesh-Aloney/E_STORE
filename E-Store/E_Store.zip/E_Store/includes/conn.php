<?php
$con = mysqli_connect('localhost', 'root', '', 'e-store', '3308');
session_start();
?>