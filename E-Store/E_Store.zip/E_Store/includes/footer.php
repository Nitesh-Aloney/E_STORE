<?php include 'login.php'; ?>
<div class='footd'>
    <footer class="navbar navbar-default">
        <div class="container">
            <center><h4 class="footinfo">Copyright © Lifestyle Store. All Rights Reserved.</h4></center>
            <div class="navigation">
                <?php if (!isset($_SESSION['email'])) { ?>
                    <a href="#loginmodal" data-toggle='modal'>login</a>
                    <a href="signup.php">signup</a>
                <?php } ?>
                <a href="contactus.php">Contact us</a>
                <a href="about.php">About Us</a>
                <a>phone: +91 90000 00000</a>
                <a>e_store@gmail.com</a>
            </div>
        </div>
    </footer>
</div>