<?php include 'login.php'; ?>
<div class="navbar navbar-default navbar-fixed-top focust">
    <div class="container">
        <div class="navbar-header">
        <button class="navbar-toggle" data-toggle="collapse" data-target="#navlist">
            <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
        </button>
        <a href="home.php" class="navbar-brand">E-STORE</a>
        </div>
        <div class="collapse navbar-collapse" id ="navlist">
            <ul class='nav navbar-nav navbar-right'>
                <?php if (!isset($_SESSION['email'])) { ?>
                    <li><a data-toggle='modal' href='#loginmodal'><span class="glyphicon glyphicon-log-in"></span> login</a></li>
                    <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> signup</a></li>
                    <li><a href="contactus.php"><span class="glyphicon glyphicon-phone"></span> Contact us</a></li>
                    <li><a href="about.php"><span class="glyphicon glyphicon-info-sign"></span> About Us</a></li>
                <?php } else { ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">go to <span class="caret"></span></a>
                        <div class="dropdown-menu goto_tar">
                            <ul type="none" >
                                <li><a href="earphones.php">Earphones</a></li>
                                <li><a href="gadgets.php">Gadgets</a></li>
                                <li><a href="about.php">About Us</a></li>
                                <li><a href="contactus.php">Contact Us</a></li>
                            </ul>                            
                        </div>
                    </li>
                    <li><a href="wishlist.php"><span class="glyphicon glyphicon-star"></span> </a></li>
                    <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> cart</a></li>
                    <li><a href="settings.php"><span class="glyphicon glyphicon-asterisk"></span> settings</a></li>
                    <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> logout</a></li>
                    <?php } ?>
            </ul>
        </div>
    </div>
</div>