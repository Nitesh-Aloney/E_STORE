<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<script src="bootstrap/js/jquery-3.5.1.min.js" type="text/javascript"></script>
<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<link href="custom.css" rel="stylesheet" type="text/css"/>