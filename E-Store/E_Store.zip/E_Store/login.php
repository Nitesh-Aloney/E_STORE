<?php
if(isset($_POST['email']) && isset($_POST['pass'])){
    $e = mysqli_real_escape_string($con,$_POST['email']);  $p=mysqli_real_escape_string($con,$_POST['pass']);
    if(!filter_var($e, FILTER_VALIDATE_EMAIL)){        header('location: msg.php?msg=error');      }
    $lgn = "select id,email,pass from users where email = '$e';";
    $lgn_res = mysqli_query($con, $lgn) or die(mysqli_error($con));
    $res = mysqli_fetch_array($lgn_res);
    if(mysqli_num_rows($lgn_res)==1){
        $pwd = $res['pass'];
        if($p==$pwd){
            $_SESSION['email'] = $e;
            $_SESSION['id'] = $res[id];
            header('location: home.php');
        } else {
            header('location: msg.php?msg=error');
        }
    } else {
        header('location: msg.php?msg=error');
    }
}
?>

<div class="modal fade" id='loginmodal'>
    <div class="modal-dialog modalsm">
        <div class="modal-content">            
            <div class="modal-body">
                <div class="modal-header lgnheader">                        
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                    <h2 class="modal-title focust">  LOGIN</h2>
                </div>
                <form class="lgnform" method="POST">
                    <div class="form-group">
                        <input class="form-control" type="email" name="email" placeholder="enter email" required/>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="pass" placeholder="enter pass" required/>
                    </div>                    
                    <div class="form-group">
                        <center><input class="btn btn-primary btn-block active" type="submit" value="submit"/></center>
                    </div>
                </form>
            </div>
            <div class="panel-footer lgnfooter">
                <h5>Do you have an account..? <a class="focust" href="signup.php">Register</a> here.</h5>
            </div>
        </div>
    </div>
</div>