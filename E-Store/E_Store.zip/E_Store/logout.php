<?php
include 'includes/conn.php';
session_encode();
session_destroy();
header('location: home.php')
?>