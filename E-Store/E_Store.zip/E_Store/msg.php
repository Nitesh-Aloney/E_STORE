<?php include 'includes/conn.php' ;
$title = $_GET['msg'];
?>
<html>
    <head>
        <title><?=$title?></title>
        <?php include 'includes/links.php' ?>
    </head>
    <body>
        <div class="container tpmrgnl">
            <div class="row">
                <?php if($title=='success'){
                    include 'includes/validation.php';
                    $uid=$_SESSION['id'];
                    $conqry = "update user_prod set status='Confirmed' where uid='$uid' and status='Added to cart';";
                    mysqli_query($con, $conqry) or die(mysqli_error($con));
                ?>
                <div class="alert-success msg">
                    <h2 class="focust">SUCCESS..!</h2>
                    <h4> Your order is confirmed and will be delivered to you shortly.</h4>
                    <h5><a href="home.php" class="alert-link focust">click here</a> to shop more</h5>
                </div>
                <?php }else{ ?>
                <div class="alert-warning msg">
                    <h2 class="focust">Error..!</h2>
                    <h4> Email or Password incorrect. if you don have an account <a href="signup.php" class="alert-link focust">signup</a></h4>
                    <h5><a href="home.php" class="alert-link focust">click here</a> to return</h5>
                </div>
                <?php } ?>
            </div>
        </div>
    </body>
</html>
