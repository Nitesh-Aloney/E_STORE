<?php include 'includes/conn.php';
$return = $_GET['ret'];
$meth = $_GET['met'];
$uid = $_SESSION['id'];
$pid = $_GET['pid'];
if($meth=='cart'){
    $status='Added to cart';    
}
elseif ($meth=='wish') {$status='wishlist';}
$cqry = "delete from user_prod where uid='$uid' and pid='$pid' and status='$status'";
mysqli_query($con, $cqry) or die(mysqli_error($con));
header("location: $return");
?>
