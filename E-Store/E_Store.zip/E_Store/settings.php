<?php include 'includes/conn.php'; 
$e=$_SESSION['email'];
$uid = $_SESSION['id'];
$setqry = "select * from users where id='$uid';";
$setqry_res = mysqli_query($con, $setqry) or die(mysqli_error($con));
$res = mysqli_fetch_array($setqry_res);?>

<html>
    <head>
        <title>settings</title>
        <?php include 'includes/links.php' ?>
    </head>
    <body>
        <?php  include 'includes/validation.php';  include 'includes/header.php';?>
        
        <div class="container tpmrgnm">
            <div class="row">
                <table class="col-xs-8 col-xs-offset-2 table-striped settab">
                    
                    <tr><td class="text-capitalize focust">DETAILS</td></tr>
                    <tr><td><?= $res['name'] ?></td></tr>
                    <tr><td><?= $res['email'] ?></td></tr>
                    <tr><td><?= $res['phone'] ?></td></tr>
                    <tr><td><?= $res['city'] ?></td></tr>
                    <tr><td><?= $res['address'] ?></td></tr>
                    <tr><td><a href="changepass.php" class="btn btn-info btn-block">Change Password</a></td><tr>
                
                </table>
            </div>
        </div> 
        
        <div class="navbar-fixed-bottom"><?php include 'includes/footer.php'; ?></div>
    </body>
</html>
