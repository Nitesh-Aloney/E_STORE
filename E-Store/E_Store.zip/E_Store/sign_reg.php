<?php
include 'includes/conn.php';
$n = mysqli_real_escape_string($con,filter_input(INPUT_POST, 'name'));
$e = mysqli_real_escape_string($con,filter_input(INPUT_POST, 'email'));
if(!filter_var($e, FILTER_VALIDATE_EMAIL)){    header('location:signup.php?email_err=*email Invalid');    exit();  };
$chk = "select email from users where email='$e';";
$chk_res = mysqli_query($con, $chk) or die(mysqli_error($con));
if(mysqli_num_rows($chk_res)!=0){    header('location:signup.php?email_err=*email exists');    exit();  };

$p = mysqli_real_escape_string($con,filter_input(INPUT_POST, 'pass'));
if(strlen($p)<6){    header('location:signup.php?pass_err=*atleast 6 characters');    exit();  };

$ph = mysqli_real_escape_string($con,filter_input(INPUT_POST, 'phone'));
$c = mysqli_real_escape_string($con,filter_input(INPUT_POST, 'city'));
$a = mysqli_real_escape_string($con,filter_input(INPUT_POST, 'adr'));
$sgnqry = "insert into users (name,email,pass,phone,city,address) values ('$n','$e','$p','$ph','$c','$a');";
$sgnqry_res = mysqli_query($con, $sgnqry) or die(mysqli_error($con));
$_SESSION['id'] = mysqli_insert_id($con);
$_SESSION['email'] = $e;
header('location: home.php');

?>
        

