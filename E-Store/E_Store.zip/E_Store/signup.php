<?php include 'includes/conn.php'; ?>
<html>
    <head>
        <title>Sign Up</title>
        <?php include 'includes/links.php'; ?>
        <style>
            
        </style>
    </head>
    <body>
        <?php include 'includes/header.php' ?>
        
        <div class="container tpmrgnm">
            <div class="row">
                <div class="col-xs-10 col-xs-offset-1 col-md-6 col-md-offset-3">
                    <form class="signform" method="POST" action="sign_reg.php">
                        <h3 class="focust">SIGN UP</h3>
                        <div class="form-group">
                            <input type="text" name="name" placeholder="Full Name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" placeholder="Email: abc@xyz.com" class="form-control" required>
                            <span class="error">
                                <?php if(isset($_GET['email_err'])){ echo $_GET['email_err']; } ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <input type="password" name="pass" placeholder="Password" class="form-control" required>
                            <span class="error">
                                <?php if(isset($_GET['pass_err'])){ echo $_GET['pass_err']; } ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <input type="tel" name="phone" placeholder="Contact no: 8744005678" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="city" placeholder="enter city" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="adr" placeholder="address" class="form-control" required>
                        </div>
                        <center>
                            <div class="form-group sgnsubmit">
                                <input type="submit" name="submit" value="submit" placeholder="address" class="form-control btn btn-info" required>
                            </div>
                        </center>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="navbar-fixed-bottom"><?php include 'includes/footer.php' ?></div>
    </body>
</html>
