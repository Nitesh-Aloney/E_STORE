<?php include'includes/conn.php' ?>
<html>
    <head>
        <title>wishlist</title>
        <?php include 'includes/links.php' ?>
        <style>
            .recw tr :nth-child(2){width: 40%;}
        </style>
    </head>
    <body>
        <?php include 'includes/validation.php';  include 'includes/header.php' ?>
        
        <div class="container tpmrgnm">
            <div class="row">
                <div class="col-xs-8 col-xs-offset-2">
                    <table class="table recw">
                        <tr><th>PRODUCT</th><th>PRICE</th><th></th></tr>
                        <?php 
                        $uid = $_SESSION['id'];
                        $status = 'wishlist';
                        $carqry = "select pid,prod_name,price from user_prod inner join products on pid=products.id and uid=2 and status='$status' ";
                        $carqry_res = mysqli_query($con, $carqry) or die(mysqli_error($con));
                        $total = 0;
                        while ($row = mysqli_fetch_array($carqry_res)) { 
                            $id = $row['pid'];  
                            $goto = "earphones.php#$id"; 
                             if($id >=17){ $goto = "gadgets.php#$id"; }
                            ?>
                        <tr>
                            <td><a href="<?=$goto?>" class="btn btn-link"><?=$row['prod_name']?></a></td>
                            <td><?="Rs. ".$row['price']?></td>
                            <td><a href="add.php?met=cart2&pid=<?=$id?>&ret=wishlist.php" class="btn btn-info btn-block">Add to cart</a></td>
                        </tr>
                        <?php $total+=$row['price'];  } ?>
                        <tr>
                            <td></td>
                            <td><?="Rs. ".$total?></td>
                            <td><a href="home.php" class="btn btn-warning btn-block" >go to HOME</a></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="navbar-fixed-bottom"><?php include 'includes/footer.php' ?></div>
    </body>
</html>
